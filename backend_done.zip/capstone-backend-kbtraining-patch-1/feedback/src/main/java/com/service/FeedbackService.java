package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Feedback;
import com.repository.FeedbackRepository;

@Service
public class FeedbackService {

	@Autowired
	FeedbackRepository feedbackRepository;

	public Feedback createFeedback(Feedback feedback) {
		return feedbackRepository.save(feedback);
	}

	public List<Feedback> getAllFeedback() {
		return (List<Feedback>) feedbackRepository.findAll();
	}
	
	public List<Feedback> getFeedbackByFoodId(String foodId){
		List<Feedback> allFeedback = (List<Feedback>) feedbackRepository.findAll();
		List<Feedback> result = new ArrayList<>();
		if (allFeedback != null) {
			for (Feedback f: allFeedback) {
				if (f.getFoodId().equals(foodId)) {
					result.add(f);
				}
			}
			return result;
			
		} else {
			return null;
		}
	}
}
