package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Food;
import com.repo.FoodRepository;

@RestController
@RequestMapping("/foods")
@CrossOrigin("*")
public class FoodController {
	
	@Autowired
	private FoodRepository foodRepo;
	
	@GetMapping("/all")
	private List<Food> getAllFood(){
		List<Food> foodList = foodRepo.findAll();
		System.out.println(foodList);
		return foodList;
	}
	
	@PostMapping("/add")
	private Food addFood(@RequestBody Food food) {
		return foodRepo.save(food);
	}
	
	@GetMapping("/{id}")
	public Optional<Food> getFoodById(@PathVariable Long id){
		return foodRepo.findById(id);
	}
	
	@PutMapping("/update")
	public Food updateFood(@RequestBody Food food) {
		return foodRepo.save(food);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<HttpStatus> deleteFood(@PathVariable Long id) {
		foodRepo.deleteById(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	

}
