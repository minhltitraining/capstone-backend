package com.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Customer;
import com.repo.CustomerRepo;

@Service
public class CustomerService {
	@Autowired
	CustomerRepo customerRepo;
	
	public Optional<Customer> findCustomerByName(String name) {
		return customerRepo.findCustomerByName(name);
	}
	public Optional<Customer> findCustomerById(Long id) {
		return customerRepo.findById(id);
	}	
	public String addCustomer(Customer customer) {
		if(findCustomerByName(customer.getName()).isPresent()) {
			return "username already exist";
		}else {
			customerRepo.save(customer);
			return "registered";
		}
	}
}
