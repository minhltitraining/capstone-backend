package com.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Customer;
import com.service.CustomerService;

@Component
@RestController
@RequestMapping("customer")
@EnableJpaRepositories("com")
public class CustomerController {
	@Autowired
	CustomerService customerService;
	
	@PostMapping("/register")
	public String register(@RequestBody Customer customer) {
		return customerService.addCustomer(customer);
	}
	
	@GetMapping("/get/{name}")
	public Optional<Customer> findCustomerByName(@PathVariable String name) {
		return customerService.findCustomerByName(name);
	}
	@GetMapping("/find/{id}")
	public Optional<Customer> findCustomerById(@PathVariable Long id) {
		return customerService.findCustomerById(id);
	}
}
