import React from "react";

function LogState(props) {

    return (
        <div>
            {/* {logState} */}
        </div>
    )
}

export default LogState