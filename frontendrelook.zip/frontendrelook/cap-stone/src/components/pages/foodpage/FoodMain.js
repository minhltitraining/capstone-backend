import React from "react";

import { Paper, Button, Stack } from "@mui/material";
import Carousel from 'react-material-ui-carousel';
import "../../styles/Food.css"
import { NavLink } from 'react-router-dom';
import { PhotoSizeSelectActual } from "@mui/icons-material";
import AspectRatio from '@mui/joy/AspectRatio';

function FoodMain(props) {
    return (
        <div className="product-carousel-container" >
            <Carousel>
                <Paper>
                    <div className="product-card-container">
                        <div className="product-card" style={{ "background-image": `url(/foodbg.jpg)`}} >
                            <div className="product-detail">
                                <div className="product-poster">
                                    {/* <img src="/burger.png" alt="" /> */}
                                </div>
                                <div className="product-name">
                                    <h1>Be sure to check the <NavLink to="/sales" style={{
                                        textDecoration: 'none',
                                        color: '#FFFFFF',
                                        fontSize: 35
                                    }} >
                                        <h1 style={{
                                            fontSize: 75
                                        }} > SALES </h1>
                                    </NavLink> page for discounted food</h1>
                                </div>
                                {/* <div className="product-buttons-container">
                                    <div>
                                        <Stack spacing={5}>
                                            <Button variant="contained" style={{ minWidth: 100 }}>
                                                Product Info
                                            </Button>
                                            <Button variant="contained" style={{ minWidth: 100 }}>
                                                Add Item To Cart
                                            </Button>
                                            <Button variant="contained" style={{ minWidth: 100 }}>
                                                Vendor's Info
                                            </Button>
                                        </Stack>
                                    </div>
                                </div> */}
                            </div>
                        </div>
                    </div>
                </Paper>
            </Carousel>
        </div>
    )
}

export default FoodMain