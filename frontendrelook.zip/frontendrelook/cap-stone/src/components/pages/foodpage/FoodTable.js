import * as React from 'react';
// import PropTypes from 'prop-types';
import Box from '@mui/material/Box';
import Collapse from '@mui/material/Collapse';
import IconButton from '@mui/material/IconButton';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';

function createData(foodName, vendorName, price) {
  return {
    vendorName,
    foodName,
    price,
    reviews: [
      {
        id: '2020-01-05',
        customerName: '11091700',
        body: "This is review body",
      },
      {
        id: '2020-01-02',
        customerName: 'Anonymous',
        body: "This is review body",
      },
    ],
  };
}
const menu = [
  createData('Frozen yoghurt', 159, 6.0),
  createData('Ice cream sandwich', 237, 9.0),
  createData('Eclair', 262, 16.0, 24),
  createData('Cupcake', 305, 3.7,),
  createData('Gingerbread', 356, 16.0),
];

function Row(props) {
  const { row } = props;
  const [open, setOpen] = React.useState(false);

  return (
    <React.Fragment>
      <TableRow sx={{ '& > *': { borderBottom: 'unset' } }}>
        <TableCell align='left' sx={{ maxWidth: 100 }} >
          <IconButton
            aria-label="expand row"
            size="small"
            onClick={() => setOpen(!open)}
          >
            {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton><Box
            component={"img"} sx={{
              height: 150,
              width: 150,
              maxHeight: { xs: 233, md: 167 },
              maxWidth: { xs: 350, md: 250 },
            }}
            onClick={() => setOpen(!open)}
            alt="no real alt"
            src="/food1.jpg"
          ></Box>
        </TableCell>
        <TableCell component="th" scope="row" sx={{ fontSize: 30 }} align="center">
          {row.foodName}
        </TableCell>
        <TableCell align="center" sx={{ fontSize: 30 }}>{row.vendorName}</TableCell>
        <TableCell align="center" sx={{ fontSize: 30 }}>{row.price}</TableCell>
        <TableCell align="center" sx={{ fontSize: 30 }}> <IconButton color="primary" aria-label="add to shopping cart">
        <AddShoppingCartIcon />
      </IconButton></TableCell>
      </TableRow>
      <TableRow>
        <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
          <Collapse in={open} timeout="auto" unmountOnExit>
            <Box sx={{ margin: 1 }}>
              <Typography variant="h6" gutterBottom component="div">
                Reviews
              </Typography>
              <Table size="small" aria-label="purchases">
                <TableHead>
                  <TableRow>
                    <TableCell align='center' sx={{ fontSize: 30}}>Customer</TableCell>
                    <TableCell align="center" sx={{ fontSize: 30}}>Body</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {row.reviews.map((review) => (
                    <TableRow key={review.customerName}>
                      <TableCell align='center' sx={{ fontSize: 20}}>{review.customerName}</TableCell>
                      <TableCell align="center" sx={{ fontSize: 20}}>{review.body}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </React.Fragment>
  );
}

// Row.propTypes = {
//   row: PropTypes.shape({
//     calories: PropTypes.number.isRequired,
//     carbs: PropTypes.number.isRequired,
//     fat: PropTypes.number.isRequired,
//     history: PropTypes.arrayOf(
//       PropTypes.shape({
//         amount: PropTypes.number.isRequired,
//         customerId: PropTypes.string.isRequired,
//         date: PropTypes.string.isRequired,
//       }),
//     ).isRequired,
//     name: PropTypes.string.isRequired,
//     price: PropTypes.number.isRequired,
//   }).isRequired,
// };



export default function CollapsibleTable() {
  return (
    <TableContainer component={Paper} sx={{ backgroundColor: "inherit" }}>
      <Table aria-label="collapsible table">
        <TableHead >
          <TableRow>
            <TableCell />
            <TableCell align="center" sx={{ fontSize: 40}} >Name</TableCell>
            <TableCell align="center" sx={{ fontSize: 40 }}>Vendor</TableCell>
            <TableCell align="center" sx={{ fontSize: 40 }}>Cost&nbsp;($)</TableCell>
            <TableCell align="center" sx={{ fontSize: 40 }}>Actions&nbsp;</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {menu.map((food) => (
            <Row key={food.name} row={food} />
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
