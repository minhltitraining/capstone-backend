import * as React from 'react';
// import PropTypes from 'prop-types';
import Box from '@mui/material/Box';
import Collapse from '@mui/material/Collapse';
import IconButton from '@mui/material/IconButton';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';


function createData(foodName, vendorName, price) {
    return {
        vendorName,
        foodName,
        price,
        reviews: [
            {
                id: '2020-01-05',
                customerName: '11091700',
                body: "This is review body",
            },
            {
                id: '2020-01-02',
                customerName: 'Anonymous',
                body: "This is review body",
            },
        ],
    };
}
const menu = [
    createData('Frozen yoghurt', 159, 6.0),
    createData('Ice cream sandwich', 237, 9.0),
    createData('Eclair', 262, 16.0, 24),
    createData('Cupcake', 305, 3.7,),
    createData('Gingerbread', 356, 16.0),
];

function Row(props) {
    const { row } = props;
    const [open, setOpen] = React.useState(false);

    return (
        <React.Fragment>
            <TableRow sx={{ '& > *': { borderBottom: 'unset' } }}>
                <TableCell align='left' sx={{ maxWidth: 100 }} >
                    <IconButton
                        aria-label="expand row"
                        size="small"
                        onClick={() => setOpen(!open)}
                    >
                        {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
                    </IconButton><Box
                        component={"img"} sx={{
                            height: 120,
                            width: 150,
                            maxHeight: { xs: 233, md: 167 },
                            maxWidth: { xs: 350, md: 250 },
                        }}
                        onClick={() => setOpen(!open)}
                        alt="no real alt"
                        src="/food1.jpg"
                    ></Box>
                </TableCell>
                <TableCell component="th" scope="row" sx={{ fontSize: 35, color:"#FFFFFF" }} align="center">
                    {row.foodName}
                </TableCell>
                <TableCell align="center" sx={{ fontSize: 35, color:"#FFFFFF" }}>{row.vendorName}</TableCell>
                <TableCell align="center" sx={{ fontSize: 35, color:"#FFFFFF" }}>{row.price}</TableCell>
                <TableCell align="center" sx={{ fontSize: 35, color:"#FFFFFF" }}>discount value</TableCell>
                <TableCell align="center" sx={{ fontSize: 35, color:"#FFFFFF" }}><IconButton color="primary" aria-label="add to shopping cart">
        <AddShoppingCartIcon sx={{fontSize:"50px", color:"#FFFFFF"}} />
      </IconButton></TableCell>
            </TableRow>
            <TableRow>
                <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
                    <Collapse in={open} timeout="auto" unmountOnExit>
                        <Box sx={{ margin: 1 }}>
                            <Typography variant="h6" gutterBottom component="div">
                                Reviews
                            </Typography>
                            <Table size="small" aria-label="purchases">
                                <TableHead>
                                    <TableRow>
                                        <TableCell align='center' sx={{ fontSize: 30, color:"#FFFFFF"}}>Customer</TableCell>
                                        <TableCell align='center' sx={{ fontSize: 30, color:"#FFFFFF"}}>Body</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {row.reviews.map((review) => (
                                        <TableRow key={review.customerName}>
                                            <TableCell align='center' sx={{ fontSize: 20, color:"#FFFFFF"}}>{review.customerName}</TableCell>
                                            <TableCell align='center' sx={{ fontSize: 20, color:"#FFFFFF"}}>{review.body}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </Box>
                    </Collapse>
                </TableCell>
            </TableRow>
        </React.Fragment>
    );
}

export default function FoodSales() {
    return (
        <div style={{ "background-image": `url(/food2.jpg)`, "background-color": "hsla(0, 0%, 0%, 0.8)", "class":"mask"}} >  
            <TableContainer component={Paper} sx={{ backgroundColor: "inherit" }} >
            <h1>WELCOME TO THE SALES SECTION</h1>
            <h2>Enjoy discounts from local vendors</h2>
                <Table aria-label="collapsible table" >
                    <TableHead >
                        <TableRow>
                            <TableCell />
                            <TableCell align="center" sx={{ fontSize: 40, color:"#FFFFFF"}} >Name</TableCell>
                            <TableCell align="center" sx={{ fontSize: 40, color:"#FFFFFF"}}>Vendor</TableCell>
                            <TableCell align="center" sx={{ fontSize: 40, color:"#FFFFFF"}}>Cost&nbsp;($)</TableCell>
                            <TableCell align="center" sx={{ fontSize: 40, color:"#FFFFFF"}}>Discount(%)</TableCell>
                            <TableCell align="center" sx={{ fontSize: 40, color:"#FFFFFF"}}>Actions&nbsp;</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {menu.map((food) => (
                            <Row key={food.name} row={food} />
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </div>
    );
}