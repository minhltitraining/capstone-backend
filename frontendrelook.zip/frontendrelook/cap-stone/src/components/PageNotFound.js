import React from "react";

function PageNotFound(){
    return(
        <div>
            What you are trying to find does not exist
        </div>
    )
}

export default PageNotFound