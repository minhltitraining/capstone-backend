import httpClient from "../../httpclientmain/httpmain"

const addReview = (review) => {
    return httpClient.get(`/ms/review/add`, review)
}
const getAllVendors = () =>{
    return httpClient.get("/ms/vendor/all")
 }

 const miscellaneousFunctions = {
    addReview, getAllVendors
 }

export default miscellaneousFunctions