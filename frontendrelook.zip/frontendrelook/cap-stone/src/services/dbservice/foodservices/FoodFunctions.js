import httpClient from "../../httpclientmain/httpmain"

const getAllFood = () => {
    return httpClient.get(`/food/all`)
}

const addFood = food => {
    return httpClient.post("/food/add", food)
}

const updateFood = (food, id) => {
    return httpClient.put(`/food/update/${id}`, food)
}

const deleteFood = id => {
    return httpClient.delete(`/food/delete/${id}`)
}

const foodFunctions = {
    getAllFood, addFood, updateFood, deleteFood
}

export default foodFunctions