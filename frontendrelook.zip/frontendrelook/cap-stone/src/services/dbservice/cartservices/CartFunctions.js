import httpClient from "../../httpclientmain/httpmain"

const getAllCart = () =>{
   return httpClient.get("/cart/all")
}

const getCartByUserName = userName =>{
    return httpClient.get(`/cart/get/${userName}`)
}

const addNewCart = cart =>{
    return httpClient.post("/cart/add", cart)
}

const updateCart = (cart, id) =>{ 
    return httpClient.put(`/cart/update/${id}`, cart)
}

const cartFunctions = {
    getAllCart, getCartByUserName, addNewCart, updateCart
}
export default cartFunctions