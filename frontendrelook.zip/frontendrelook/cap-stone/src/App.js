import './App.css';

import Nav from "./components/Navigation/Nav"

function App() {
  return (
    <div className="App">
      {/* <ThemeProvider theme={darkTheme}> */}
        <Nav/>
      {/* </ThemeProvider> */}
    </div>
  );
}

export default App;
